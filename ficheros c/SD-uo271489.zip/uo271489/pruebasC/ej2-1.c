#include <stdio.h>

int main()
{
   int n = 25;  // una variable entera
   printf("La variable n vale %d\n", n);
   printf("Esta almacenada en la dirección %p\n", &n);
}
