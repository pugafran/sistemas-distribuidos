public class prueba{
	public static void main(String [] args){
		System.out.printf("Número de argumentos: %i",args.length);	
	}

}
