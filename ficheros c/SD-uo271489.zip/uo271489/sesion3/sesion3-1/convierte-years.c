// Fichero: convierte-a-decimal.c
#include <stdio.h>
int main()
{
    unsigned long int numero = 0xe7b172ec;  // Pon el tuyo
    printf("%lu", numero);
    return 0;
}
